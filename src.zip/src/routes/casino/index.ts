import { Router } from 'express';

const router = Router();

// TODO: Implement routes
// router.post('/games/blackjack/start', startBlackjack);
// router.post('/games/poker/create-lobby', createPokerLobby);
// router.post('/games/cases/open', openCase);
// router.post('/games/cases/battle', createCaseBattle);
// router.post('/games/crash/start', startCrash);
// router.post('/games/mines/start', startMines);
// router.post('/games/dice/roll', rollDice);
// router.post('/games/upgrader/upgrade', upgradeCard);
// router.post('/games/snake/start', startSnake);
// router.get('/winners', getRecentWinners);

export default router;

